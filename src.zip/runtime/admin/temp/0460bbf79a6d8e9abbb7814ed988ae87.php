<?php /*a:1:{s:42:"E:\tp\src\app\admin\view\post\postsee.html";i:1621262856;}*/ ?>
<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
<script type="text/javascript" src="/static/layui/layui.js"></script>

<div class="layui-card">
    <div class="layui-card-body">
        <form class="layui-form layui-form-pane">
            <div class="layui-form-item">
                <label class="layui-form-label">文章标题：</label>
                <div class="layui-input-block">
                    <input type="text" name="title" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($post['title']); ?>" autocomplete="off" class="layui-input" style="width: 87%">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">文章作者：</label>
                <div class="layui-input-inline">
                    <input type="text" name="author" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($post['author']); ?>" autocomplete="off" class="layui-input">
                </div>
                <label class="layui-form-label">发布时间：</label>
                <div class="layui-input-inline">
                    <input type="text" name="date" disabled required id="date"  lay-verify="required" placeholder="<?php echo htmlentities($post['date']); ?>" autocomplete="off" class="layui-input">
                </div>
                <label class="layui-form-label">文章排序：</label>
                <div class="layui-input-inline">
                    <input type="number" name="sort_id" disabled placeholder="<?php echo htmlentities($post['sort_id']); ?>" autocomplete="off" class="layui-input">
                </div>
                <!--        <div class="layui-form-mid layui-word-aux">辅助文字</div>-->
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">文章分类：</label>
                <div class="layui-input-inline">
                    <select name="type" lay-verify="required" disabled>
                        <?php foreach($type as $key=>$obj): ?>
                        <option value="<?php echo htmlentities($obj['id']); ?>" <?php if($post['type']==$obj['id']): ?> selected <?php endif; ?>><?php echo htmlentities($obj['category']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <label class="layui-form-label">文章密码:</label>
                <div class="layui-input-inline">
                    <input type="password" name="password" disabled  placeholder="<?php if($post['password']==0): ?>无<?php else: ?><?php echo htmlentities($post['password']); ?><?php endif; ?>" autocomplete="off" class="layui-input">
                </div>
                <label class="layui-form-label">访问人数：</label>
                <div class="layui-input-inline">
                    <input type="text" name="views" disabled  placeholder="<?php echo htmlentities($post['views']); ?>" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">文章标签：</label>
                <div class="layui-input-inline">
                    <input type="text" name="tags" disabled placeholder="<?php echo htmlentities($post['tags']); ?>" autocomplete="off" class="layui-input">
                </div>

                <label class="layui-form-label">是否隐藏：</label>
                <div class="layui-input-inline">
                    <input type="text" placeholder="<?php echo htmlentities($post['hide']); ?>" class="layui-input" disabled>
                </div>

                <label class="layui-form-label">是否置顶：</label>
                <div class="layui-input-inline">
                    <input type="text" placeholder="<?php if($post['top']=='n'): ?>未置顶<?php else: ?>已置顶<?php endif; ?>" class="layui-input" disabled>
                </div>
            </div>


            <div class="layui-form-item">
                <div class="layui-textarea layui-form-mid" ><a href="javascript:;" class="layui-btn">前台展示</a></div>
<!--                </div>-->
            </div>

        </form>

    </div>

</div>