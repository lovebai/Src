<?php /*a:1:{s:40:"E:\tp\src\app\admin\view\bug\bugsee.html";i:1621405774;}*/ ?>
<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
<script type="text/javascript" src="/static/layui/layui.js"></script>
<div class="layui-card">
<div class="layui-card-body">
<form class="layui-form layui-form-pane">
    <div class="layui-form-item"></div>
    <div class="layui-form-item">
        <label class="layui-form-label">标题：</label>
        <div class="layui-input-inline">
            <input type="text" name="title" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($data['title']); ?>" autocomplete="off" class="layui-input">
        </div>
        <label class="layui-form-label">提交者：</label>
        <div class="layui-input-inline">
            <input type="text" name="title" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($data['author']); ?>" autocomplete="off" class="layui-input">
        </div>
        <label class="layui-form-label">分类：</label>
        <div class="layui-input-inline">
            <input type="text" name="title" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($type); ?>" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">等级：</label>
        <div class="layui-input-inline">
            <input type="text" name="title" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($data['grade']); ?>" autocomplete="off" class="layui-input">
        </div>
        <label class="layui-form-label">状态：</label>
        <div class="layui-input-inline">
            <input type="text" name="title" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($data['status']); ?>" autocomplete="off" class="layui-input">
        </div>
        <label class="layui-form-label">附件：</label>
        <div class="layui-input-inline">
            <?php if($file['filepath']!=''): ?>
            <a href="<?php echo htmlentities($file['filepath']); ?>"  class="layui-btn layui-bg-blue" style="width: 100%" _target="block" >附件下载</a>
            <?php else: ?>
            <label class="layui-btn layui-bg-red" style="width: 100%">未上传附件</label>
            <?php endif; ?>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">提交时间：</label>
        <div class="layui-input-block">
            <input type="text" name="date" disabled required  lay-verify="required" placeholder="<?php echo htmlentities($data['subdate']); ?>" autocomplete="off" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">描述：</label>
        <div class="layui-input-block">
            <div name="desc" disabled placeholder="" class="layui-textarea"><?php echo $data['content']; ?></div>
        </div>
    </div>

</form>
</div>
</div>
