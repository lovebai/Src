<?php /*a:2:{s:45:"E:\tp\src\app\admin\view\admin\adminlist.html";i:1622171106;s:43:"E:\tp\src\app\admin\view\common\common.html";i:1622027001;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>后台管理员列表 - 后台管理中心</title>
  <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
  <link rel="stylesheet" type="text/css" href="/static/css/admin.index.css" />
  
  <style>
    /* 移动端 */
    @media screen and (max-width: 768px) {
      .layui-layout-admin .layui-layout-left,
      .layui-layout-admin .layui-body,
      .layui-layout-admin .layui-footer{left: 0;}
      .layui-layout-admin .layui-side{left: -300px;}
    }
  </style>
</head>
<body class="layui-layout-body">
<div class="layui-layout layui-layout-admin">
  <div class="layui-header">
    <div class="layui-logo layui-hide-xs layui-bg-black">
      <img src="/static/images/logo.svg" width="36px"/> <span style="color: #2d90d9;font: icon;font-weight: 700;">后台管理中心</span>
    </div>

    <ul class="layui-nav layui-layout-left">
      <!-- 移动端显示 -->
      <li class="layui-nav-item layui-show-xs-inline-block layui-hide-sm" lay-header-event="menuLeft">
        <i class="layui-icon layui-icon-spread-left"></i>
      </li>

      <li class="layui-nav-item layui-hide-xs"><a href="">欢迎光临！</a></li>
      <li class="layui-nav-item layui-hide layui-hide-xs"><a href="">PC</a></li>
      <li class="layui-nav-item layui-hide  layui-hide-xs"><a href="">PC</a></li>
      <li class="layui-nav-item layui-hide  layui-hide-xs"><a href="">PC</a></li>
      <li class="layui-nav-item layui-hide ">
        <a href="javascript:;">其他</a>
        <dl class="layui-nav-child">
          <dd><a href="">menu 11</a></dd>
          <dd><a href="">menu 22</a></dd>
          <dd><a href="">menu 33</a></dd>
        </dl>
      </li>
    </ul>

    <ul class="layui-nav layui-layout-right">
      <li class="layui-nav-item" lay-unselect>
        <a href="javascript:;" lay-header-event="refresh" title="刷新">
          <i class="layui-icon layui-icon-refresh-3"></i>
        </a>
      </li>
      <li class="layui-nav-item layui-hide layui-show-md-inline-block">
        <a href="javascript:;">
          <img id="avatar" src="" class="layui-nav-img"><span id="user"></span>
        </a>
        <dl class="layui-nav-child">
          <dd><a href="javascript:;" id="preference">个人资料</a></dd>
          <dd><a href="javascript:;" id="logout">退出系统</a></dd>
        </dl>
      </li>
      <li class="layui-nav-item" lay-header-event="menuRight" lay-unselect>
        <a href="javascript:;">
          <i class="layui-icon layui-icon-more-vertical"></i>
        </a>
      </li>
    </ul>
  </div>


  <div class="layui-side layui-bg-black site-mobile">
    <div class="layui-side-scroll ">
      <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
      <ul class="layui-nav  layui-nav-tree" lay-filter="test" lay-shrink="all">
        <li class="layui-nav-item "><a href="<?php echo url('index/index'); ?>"><i class="layui-icon layui-icon-home"></i> 控制台</a></li>
<!--        <li class="layui-nav-item layui-nav-itemed">-->
        <li class="layui-nav-item">
          <a class="" href="javascript:;"><i class="layui-icon layui-icon-senior"></i> 漏洞管理</a>
          <dl class="layui-nav-child">
            <dd class=" layui-icon"><a href="<?php echo url('bug/index'); ?>"><i class="layui-icon layui-icon-spread-left"></i> 漏洞列表</a></dd>
            <dd class=""><a href="<?php echo url('bug/category'); ?>"> <i class="layui-icon layui-icon-menu-fill"></i> 漏洞分类</a></dd>
          </dl>
        </li>
        <li class="layui-nav-item">
          <a href="javascript:;"><i class="layui-icon layui-icon-release"></i> 文章管理</a>
          <dl class="layui-nav-child">
            <dd class=""><a href="<?php echo url('post/addpost'); ?>">添加文章</a></dd>
            <dd class=""><a href="<?php echo url('post/index'); ?>">文章列表</a></dd>
            <dd class=""><a href="<?php echo url('post/category'); ?>">文章分类</a></dd>
          </dl>
        </li>

        <li class="layui-nav-item layui-disabled" id="dev">
          <a href="javascript:;"><i class="layui-icon layui-icon-gift" style="font-size: 18px;"></i> 活动管理</a>
          <dl class="layui-nav-child">
<!--            <dd class=""><a href="<?php echo url('gift/add'); ?>">添加活动</a></dd>-->
            <dd class=""><a href="javascript:;">添加活动</a></dd>
<!--            <dd class=""><a href="<?php echo url('gift/list'); ?>">活动列表</a></dd>-->
            <dd class=""><a href="javascript:;">活动列表</a></dd>
          </dl>
        </li>

        <li class="layui-nav-item layui-disabled" id="dev1">
          <a href="javascript:;"><i class="layui-icon layui-icon-release"></i> 厂商管理</a>
          <dl class="layui-nav-child">
            <dd class="{block name=''}{/block}"><a href="javascript:;">添加厂商</a></dd>
            <dd><a href="javascript:;">厂商列表</a></dd>
          </dl>
        </li>

        <li class="layui-nav-item layui-disabled" id="dev2">
          <a href="javascript:;"><i class="layui-icon layui-icon-fire"></i> 漏洞预警</a>
          <dl class="layui-nav-child">
            <dd class="{block name=''}{/block}"><a href="javascript:;">添加预警</a></dd>
            <dd><a href="javascript:;">预警列表</a></dd>
          </dl>
        </li>


        <li class="layui-nav-item layui-nav-itemed">
          <a href="javascript:;"><i class="layui-icon layui-icon-group"></i> 用户管理</a>

          <dl class="layui-nav-child">
            <ul class="layui-nav layui-nav-tree ">
              <li class="layui-nav-item" >
                <a href="javascript:;"><i class="layui-icon layui-icon-user"></i>&nbsp;普通用户</a>
                <dl class="layui-nav-child">
                  <dd class=""><a href="<?php echo url('user/add'); ?>">添加用户</a></dd>
                  <dd class=""><a href="<?php echo url('user/list'); ?>">用户列表</a></dd>
                </dl>
              </li>

              <li class="layui-nav-item" >
                <a href="javascript:;"><i class="layui-icon layui-icon-friends"></i>&nbsp;后台用户</a>
                <dl class="layui-nav-child">
                  <dd class=""><a href="<?php echo url('admin/add'); ?>">添加用户</a></dd>
                  <dd class="
layui-this
"><a href="<?php echo url('admin/list'); ?>">用户列表</a></dd>
                </dl>
              </li>
            </ul>

          </dl>

        </li>

        <li class="layui-nav-item">
          <a href="javascript:;"><i class="layui-icon layui-icon-set-fill"></i> 网站设置</a>
          <dl class="layui-nav-child">
            <dd class=""><a href="<?php echo url('setting/index'); ?>"><i class="layui-icon layui-icon-set-sm"></i> 站点信息</a></dd>
            <dd class=""><a href="<?php echo url('setting/link'); ?>"><i class="layui-icon layui-icon-link"></i> 友情链接</a></dd>
            <dd class=""><a href="<?php echo url('setting/nav'); ?>"><i class="layui-icon layui-icon-menu-fill"></i> 导航设置</a></dd>
          </dl>
        </li>

        <li class="layui-nav-item">
          <a href="javascript:;"><i class="layui-icon layui-icon-set-fill"></i> 其他设置</a>
          <dl class="layui-nav-child">

            <!--暂时未想到要开发什么功能，以后在用吧  -->
<!--            <dd class=""><a href="<?php echo url('conf/set'); ?>"><i class="layui-icon layui-icon-menu-fill"></i> 通知设置</a></dd>-->
            <dd class=""><a href="<?php echo url('conf/sms'); ?>"><i class="layui-icon layui-icon-set-sm"></i> 短信配置</a></dd>
            <dd class=""><a href="<?php echo url('conf/mail'); ?>"><i class="layui-icon layui-icon-link"></i> 邮箱配置</a></dd>
          </dl>
        </li>

<!--        <li class="layui-nav-item "><a href="<?php echo url('setting/index'); ?>"><i class="layui-icon layui-icon-set-sm"></i> 站点配置</a></li>-->
      </ul>
    </div>
  </div>

  <div class="layui-body">
    <div class="layui-hide-sm layui-hide-lg layui-hide-md layui-bg-orange"><h1>请使用电脑访问后台~</h1></div>
    <!-- 内容主体区域 -->
    
<div class="layui-card">
  <div class="layui-card-body">
    <table id="table" lay-filter="test"></table>
  </div>
</div>


  </div>

  <!-- 辅助元素，一般用于移动设备下遮罩 -->
  <div class="layadmin-body-shade" layadmin-event="shade"></div>
</div>

<!--  <div class="layui-footer">-->
<!--     底部固定区域-->
<!--  </div>-->
</div>
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script>
  //JS
  layui.use(['element', 'layer', 'util', 'jquery'], function(){
    var element = layui.element
            ,layer = layui.layer
            ,util = layui.util
            ,$ = layui.$;

    $.ajax({
      url:'<?php echo url("index/avatar"); ?>',
      method:'post',
      success:(res)=>{
        $('#avatar').attr('src',res.avatar)
        $('#user').html(res.user)
      }
    })

    //头部事件
    util.event('lay-header-event', {
      //左侧菜单事件
      menuLeft: function(othis){
        layer.msg('展开左侧菜单的操作', {icon: 0});
      }
       ,menuRight: function(){
        layer.open({
          type: 1
          ,title:'提示说明'
          ,content: '<div style="padding: 15px;">小白版权所有，具体内容以后加</div>'
          ,area: ['260px', '100%']
          ,offset: 'rt' //右上角
          ,anim: 5
          ,shadeClose: true
        });
      },
      refresh:()=>{
        location.reload()
      }
    });

    //个人资料
    $("#preference").click(()=>{
      layer.open({
        type: 2,
        title: '个人资料修改',
        shadeClose: true,
        shade: 0.8,
        area: ['45%', '60%'],
        content: '<?php echo url("index/preference"); ?>'
      });
    })

    //退出
    $("#logout").click(()=>{
      layer.confirm('您确定要退出吗？', {
        btn: ['是的','不退'] //按钮
      }, function(){
        layer.msg('已退出', {icon: 1});
        setTimeout(()=>{
          location.href='<?php echo url("login/logout"); ?>'
        },2000)

      }, function(){
        layer.msg('您阁这和我闹着玩呢！', {
          time: 5000, //20s后自动关闭
        });
      });
    })

    $('#dev').click(()=>{
      layer.msg('该功能正在加急开发中！敬请期待', {
        time: 5000, //20s后自动关闭
      });
    })
    $('#dev1').click(()=>{
      layer.msg('该功能正在加急开发中！敬请期待', {
        time: 5000, //20s后自动关闭
      });
    })
    $('#dev2').click(()=>{
      layer.msg('该功能正在加急开发中！敬请期待', {
        time: 5000, //20s后自动关闭
      });
    })

  });
</script>

<script type="text/html" id="tobar">
  <div class="layui-btn-container">
    <span class="layui-btn layui-btn-radius layui-btn-primary layui-font-18">后台用户列表</span>
  </div>
</script>
<!--操作-->
<script type="text/html" id="rightbar">
  <div class="layui-btn-container">
    <button class="layui-btn layui-btn-sm  layui-btn-normal" lay-event="edit">编辑</button>
    <button class="layui-btn layui-btn-sm  layui-btn-danger" lay-event="del">删除</button>
  </div>
</script>

<script>
  layui.use('table', function(){
    const table = layui.table;
    const layer = layui.layer;
    const $ = layui.$;

    table.render({
      elem: '#table'
      ,toolbar:'#tobar'
      ,url: '<?php echo url("admin/datalist"); ?>' //数据接口
      ,page: true //开启分页
      ,even: true //开启隔行背景
      ,method:'post'
      ,limit:11
      ,cols: [[ //表头
        {field: 'username', title: '用户名',align: 'center'}
        ,{field: 'name', title: '用户姓名',align: 'center'}
        ,{field: 'qq', title: 'QQ', align: 'center'}
        ,{field: 'avatar', title: '头像',align: 'center'}
        ,{field: 'status', title: '状态',width: 130,align: 'center',sort: true}
        ,{field: 'operation', title: '操作',align:'center',toolbar:'#rightbar',width: 230}
      ]]
      ,parseData: function(res){ //res 即为原始返回的数据
        return {
          "code": res.code, //解析接口状态
          "msg": res.msg, //解析提示文本
          "count": res.count, //解析数据长度
          "data": res.data.data //解析数据列表
        };
      }
      ,response: {
        statusName: 'code' //规定数据状态的字段名称，默认：code
        ,statusCode: 200 //规定成功的状态码，默认：0
        ,msgName: 'msg' //规定状态信息的字段名称，默认：msg
        ,countName: 'count' //规定数据总数的字段名称，默认：count
        ,dataName: 'data' //规定数据列表的字段名称，默认：data
      }
    });

    table.on('tool(test)', (obj)=>{
      switch (obj.event){
        case 'edit':
          //编辑
          layer.open({
            title:'编辑',
            type: 2,
            maxmin:true,
            area: ['45%', '70%'], //宽高
            content: '<?php echo url("admin/edit"); ?>?id='+obj.data.id,
            cancel:()=>{
              //重载表格
              table.reload('table')
            }
          });
          break;
        case 'del':
          layer.confirm('您确定要删除'+obj.data.username+'吗？',
                  {btn:['确认删除','取消删除']},
                  ()=>{
                    $.ajax({
                      url:'<?php echo url("admin/del"); ?>',
                      method: 'post',
                      data: {
                        id:obj.data.id
                      },
                      success:(res)=>{
                        if (res.code==200){
                          layer.msg(res.msg,{
                            icon: 6,
                            time: 1000
                          },()=>{
                            table.reload('table')
                          })
                        }else{
                          layer.msg("Error:"+res.msg,{
                            icon: 5,
                            time: 1000
                          })
                          return false
                        }
                      }
                    })
                  },
                  ()=>{
                    layer.msg("您已取消了删除管理员操作")
                  })

          break;
      }
    });
  });
</script>

</body>
</html>