<?php /*a:1:{s:35:"E:\tp\src\app\admin\view\login.html";i:1621758075;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>后台登录中心</title>
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/login.main.css" />
</head>
<body>

<div class="layui-form">
    <div class="container">
        <div class="layui-form-mid layui-word-aux">
<!--            <img id="logoid" src="06.png" height="35">-->
            <span id="logoid">后台管理中心</span>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">管理账号</label>
            <div class="layui-input-block">
                <input type="text" id="username" name="username" required  lay-verify="required|email" placeholder="请输入用户名" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">管理密码</label>
            <div class="layui-input-inline">
                <input type="password" name="password" required lay-verify="required" placeholder="请输入密码" autocomplete="off" class="layui-input">
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">验证码</label>
            <div class="layui-input-inline">
                <input type="text" name="code" required  lay-verify="required" placeholder="请输入验证码" autocomplete="off" class="layui-input verity">
            </div>
            <label class="captcha"><?php echo captcha_img(); ?></label>
        </div>

        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" id="submit" lay-submit lay-filter="formDemo">登陆</button>
            </div>
        </div>

    </div>
</div>
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script>
    layui.use('form', function(){
        var form = layui.form;
        var $ = layui.$;
        var layer = layui.layer;
        $('#username').focus()
        $(document).keyup(function(event){
            if(event.keyCode ==13){
                $("#submit").trigger("click");
            }
        });

        //监听提交
        form.on('submit(formDemo)', function(data){
            // layer.msg(JSON.stringify(data.field));
            // return false;
            $.ajax({
                url:'<?php echo url("login/login"); ?>',
                method:'post',
                data:data.field,
                success:(res)=>{
                    if(res.code==200){
                        layer.msg('恭喜您登录成功！', {
                            time: 1300,
                            icon:6,
                        });
                            setTimeout(()=>{
                                location.href=res.url
                            },1500)
                    }else{
                        layer.alert(res.msg, {
                            icon: 5,
                            title:'错误提示',
                            closeBtn:false,
                            time:1300,
                            btn:'关闭'
                        })
                        $('img').attr('src',"/captcha.html?"+Math.random())
                    }
                }
            })
        });
    });
</script>
</body>
</html>