<?php /*a:1:{s:42:"E:\tp\src\app\admin\view\user\usersee.html";i:1621493479;}*/ ?>
<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
<script type="text/javascript" src="/static/layui/layui.js"></script>
<form class="layui-form layui-form-pane" action="">
    <div class="layui-form-item"></div>
    <div class="layui-form-item">
        <label class="layui-form-label">用户名：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['username']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>

        <label class="layui-form-label">用户手机：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['phone']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>

        <label class="layui-form-label">用户邮箱</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['email']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>
    </div>

    <div class="layui-form-item">
        <div class="layui-hide">
        <label class="layui-form-label">用户密码：</label>
        <div class="layui-input-inline">
            <input type="text"  placeholder="<?php echo htmlentities($info['password']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>
        </div>

        <label class="layui-form-label">用户性别：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['gender']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>

        <label class="layui-form-label">用户生日:</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['birthday']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>
        <label class="layui-form-label">用户状态：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['status']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">用户团队：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['team']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>

        <label class="layui-form-label">用户微信：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['wechat']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>

        <label class="layui-form-label">用户QQ:</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['qq']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">注册时间：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['create_date']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>


        <label class="layui-form-label">用户简介：</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['about']); ?>" autocomplete="off" class="layui-input" disabled>
        </div>

        <label class="layui-form-label">用户头像:</label>
        <div class="layui-input-inline">
            <input type="text" placeholder="<?php echo htmlentities($info['avatar']); ?>" value="<?php echo htmlentities($info['avatar']); ?>" id="avatar" autocomplete="off" class="layui-input layui-hide" disabled>
            <label class="layui-btn" id="prv">头像预览</label>
        </div>
    </div>

</form>

<script>
    //Demo
    layui.use('form', function(){
        var form = layui.form;
        var layer = layui.layer;
        var $ = layui.$;

        //监听提交
        form.on('submit(formDemo)', function(data){
            layer.msg(JSON.stringify(data.field));
            return false;
        });

        //图片预览
        $('#prv').click(()=>{
            let avatar=$("#avatar").val()
            if(avatar!=''){
                layer.open({
                    type: 1,
                    title:'预览',
                    closeBtn:0,
                    time:2000,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['420px', '280px'], //宽高
                    content: '<img src="'+avatar+'" width="100%" height="230px">'
                });
                return false
            }else {
                layer.msg("还未上传头像");
            }
            return false
        })
    });
</script>