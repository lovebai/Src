<?php /*a:1:{s:43:"E:\tp\src\app\admin\view\user\useredit.html";i:1621654885;}*/ ?>
<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
<script type="text/javascript" src="/static/layui/layui.js"></script>
<div class="layui-card">
    <div class="layui-card-body">
<form class="layui-form layui-form-pane" action="" xmlns="http://www.w3.org/1999/html" id="form">
    <div class="layui-form-item"></div>
    <div class="layui-form-item layui-hide">
        <label class="layui-form-label">id：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['id']); ?>" name="id" autocomplete="off" class="layui-input" required  lay-verify="required">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">用户名：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['username']); ?>" name="username" autocomplete="off" class="layui-input" required  lay-verify="required">
        </div>

        <label class="layui-form-label">用户手机：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['phone']); ?>" name="phone" autocomplete="off" class="layui-input" required  lay-verify="required">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">用户邮箱</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['email']); ?>" name="email" autocomplete="off" class="layui-input" required  lay-verify="required">
        </div>

        <label class="layui-form-label">用户密码：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['password']); ?>" name="password" autocomplete="off" class="layui-input" >
        </div>

    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">用户性别：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['gender']); ?>" name="gender" autocomplete="off" class="layui-input" required  >
        </div>

        <label class="layui-form-label">用户生日:</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['birthday']); ?>" name="birthday" id="time" autocomplete="off" class="layui-input">
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">用户团队：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['team']); ?>" name="team" autocomplete="off" class="layui-input" >
        </div>

        <label class="layui-form-label">用户微信：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['wechat']); ?>" name="wechat" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">用户QQ:</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['qq']); ?>" name="qq" autocomplete="off" class="layui-input">
        </div>



        <label class="layui-form-label">注册时间：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['create_date']); ?>" name="create_date" autocomplete="off" class="layui-input" required  lay-verify="required">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">用户状态：</label>
        <div class="layui-input-inline">
            <input type="checkbox" name="status" lay-skin="switch" lay-text="正常|禁用" lay-filter="filter" <?php if($status == 1): ?> checked <?php endif; ?>>

        </div>

        <label class="layui-form-label">用户简介：</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['about']); ?>" name="about" autocomplete="off" class="layui-input" >
        </div>
    </div>

    <div class="layui-form-item ">
        <label class="layui-form-label">用户头像:</label>
        <div class="layui-input-inline">
            <input type="text" value="<?php echo htmlentities($info['avatar']); ?>" name="avatar" id="avatar" autocomplete="off" class="layui-input" disabled>
        </div>
        <button type="button" class="layui-btn layui-input-inline" id="test1">
            <i class="layui-icon">&#xe67c;</i>上传图片
        </button>
        <label class="layui-btn layui-btn-normal" id="prv">预览</label>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-bg-blue" lay-submit lay-filter="formDemo">立即提交</button>
            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
        </div>
    </div>

</form>
    </div>
</div>

<script>
    //Demo
    layui.use(['form','upload','layer'], function(){
        const form = layui.form;
        const upload=layui.upload;
        const layer=layui.layer;
        const $=layui.$;
        const laydate=layui.laydate;

        laydate.render({
            elem: '#time' //指定元素
        });

        //监听提交
        form.on('submit(formDemo)', function(data){
            // layer.msg(JSON.stringify(data.field));
            console.log(data.field)
            $.ajax({
                url:'<?php echo url("user/save"); ?>',
                type:'post',
                data:data.field,
                success:(res)=>{
                    if(res.code==200){
                        layer.msg(res.msg,{
                            icon: 6,
                            time: 1000
                        },()=>{
                            location.reload();
                        })
                    }else{
                        layer.msg("Error:"+res.msg,{
                            icon: 5,
                            time: 1000
                        })
                        return false
                    }
                }

            })
            return false;
        });

        //图片上传
        upload.render({
            elem: '#test1' //绑定元素
            ,url: '<?php echo url("upload/index"); ?>' //上传接口,
            ,method:'post'
            ,accept:'images'
            ,data:{
                enctype:'multipart/form-data'
            }
            ,done: function(res){
                //上传完毕回调
                //     console.log(res.data.src)
                $("#avatar").val('/uploads/'+res.data.src)
            }
            ,error: function(){
                //请求异常回调
            }
        });

        //图片预览
        $('#prv').click(()=>{
            let avatar=$("#avatar").val()
            if(avatar!=''){
                layer.open({
                    type: 1,
                    title:'预览',
                    closeBtn:0,
                    time:2000,
                    skin: 'layui-layer-rim', //加上边框
                    area: ['420px', '280px'], //宽高
                    content: '<img src="'+avatar+'" width="100%" height="230px">'
                });
            }else {
                layer.msg("还未上传头像");
            }
        })
    });
</script>