<?php


namespace app\api\model;


use think\Model;

class Bug extends Model
{

}