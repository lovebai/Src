<?php


namespace app\api\model;


use think\Model;

class Posts extends Model
{

}