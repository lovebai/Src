<?php


namespace app\admin\controller;

//漏洞预警
class Warning
{

}