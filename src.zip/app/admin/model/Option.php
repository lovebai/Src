<?php


namespace app\admin\model;


use think\facade\Db;

class Option extends Db
{

}